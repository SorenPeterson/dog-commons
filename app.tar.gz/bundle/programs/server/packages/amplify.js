(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.amplify = {};

})();

//# sourceMappingURL=amplify.js.map
