(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var EJSON = Package.ejson.EJSON;

/* Package-scope variables */
var PersistentSession;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['u2622:persistent-session'] = {
  PersistentSession: PersistentSession
};

})();

//# sourceMappingURL=u2622_persistent-session.js.map
