//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
//                                                                      //
// If you are using Chrome, open the Developer Tools and click the gear //
// icon in its lower right corner. In the General Settings panel, turn  //
// on 'Enable source maps'.                                             //
//                                                                      //
// If you are using Firefox 23, go to `about:config` and set the        //
// `devtools.debugger.source-maps-enabled` preference to true.          //
// (The preference should be on by default in Firefox 24; versions      //
// older than 23 do not support source maps.)                           //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var HTTP = Package.http.HTTP;

/* Package-scope variables */
var GeolocationBG, device;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/zeroasterisk:cordova-geolocation-background/cordova-geolocation-background.js                     //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
// Write your package code here!                                                                              // 1
/**                                                                                                           // 2
 * This is an abstraction lib for handling backgrounded processes for GPS updates                             // 3
 *                                                                                                            // 4
 * Source:                                                                                                    // 5
 *   https://github.com/christocracy/cordova-plugin-background-geolocation                                    // 6
 *                                                                                                            // 7
 * common:                                                                                                    // 8
 *   GeolocationBG.setup()                                                                                    // 9
 *     [true/false] is this available and setup?                                                              // 10
 *   GeolocationBG.config(options)                                                                            // 11
 *     getter/setter                                                                                          // 12
 *   GeolocationBG.start()                                                                                    // 13
 *     start background process                                                                               // 14
 *   GeolocationBG.stop()                                                                                     // 15
 *     stop  background process                                                                               // 16
 *   GeolocationBG.get()                                                                                      // 17
 *     get the current location (handy shortcut)                                                              // 18
 *                                                                                                            // 19
 * internal                                                                                                   // 20
 *   GeolocationBG.setup()                                                                                    // 21
 *   GeolocationBG.send()                                                                                     // 22
 *     [internal, non-android]                                                                                // 23
 *   GeolocationBG.sendCallbackSuccess()                                                                      // 24
 *     POSTs to the configured URL                                                                            // 25
 *     submits "data" as JSON content                                                                         // 26
 */                                                                                                           // 27
GeolocationBG = {                                                                                             // 28
  // configure these options via GeolocationBG.config()                                                       // 29
  //  - options are passed into the config for Android background process                                     // 30
  //    - https://github.com/christocracy/cordova-plugin-background-geolocation                               // 31
  //  - options are passed into HTTP.get()                                                                    // 32
  //    - https://github.com/meteor/meteor/blob/master/packages/http/httpcall_client.js                       // 33
  options: {                                                                                                  // 34
    // your server url to send locations to                                                                   // 35
    //   YOU MUST SET THIS TO YOUR SERVER'S URL                                                               // 36
    //   (see the setup instructions below)                                                                   // 37
    url: 'http://example.com/api/geolocation',                                                                // 38
    params: {                                                                                                 // 39
      // will be sent in with 'location' in POST data (root level params)                                     // 40
      // these will be added automatically in setup()                                                         // 41
      //userId: GeolocationBG.userId(),                                                                       // 42
      //uuid:   GeolocationBG.uuid(),                                                                         // 43
      //device: GeolocationBG.device()                                                                        // 44
    },                                                                                                        // 45
    headers: {                                                                                                // 46
      // will be sent in with 'location' in HTTP Header data                                                  // 47
    },                                                                                                        // 48
    desiredAccuracy: 10,                                                                                      // 49
    stationaryRadius: 20,                                                                                     // 50
    distanceFilter: 30,                                                                                       // 51
    // Android ONLY, customize the title of the notification                                                  // 52
    notificationTitle: 'Background GPS',                                                                      // 53
    // Android ONLY, customize the text of the notification                                                   // 54
    notificationText: 'ENABLED',                                                                              // 55
    //                                                                                                        // 56
    activityType: 'AutomotiveNavigation',                                                                     // 57
    // enable this hear sounds for background-geolocation life-cycle.                                         // 58
    debug: false                                                                                              // 59
  },                                                                                                          // 60
                                                                                                              // 61
  // placeholders                                                                                             // 62
  bgGeo: null,                                                                                                // 63
  fgGeo: null,                                                                                                // 64
  isStarted: false,                                                                                           // 65
                                                                                                              // 66
  // start background service                                                                                 // 67
  start: function() {                                                                                         // 68
    if (!this.isStarted) {                                                                                    // 69
      this.get();                                                                                             // 70
    }                                                                                                         // 71
    if (!this.setup()) {                                                                                      // 72
      console.error('GeolocationBG unable to setup, unable to start');                                        // 73
      return false;                                                                                           // 74
    }                                                                                                         // 75
    // Turn ON the background-geolocation system.  The user will be tracked whenever they suspend the app.    // 76
    this.bgGeo.start();                                                                                       // 77
    this.isStarted = true;                                                                                    // 78
    return true;                                                                                              // 79
  },                                                                                                          // 80
                                                                                                              // 81
  // stop background service                                                                                  // 82
  stop: function() {                                                                                          // 83
    if (!this.setup()) {                                                                                      // 84
      console.error('GeolocationBG unable to setup, unable to stop');                                         // 85
      return false;                                                                                           // 86
    }                                                                                                         // 87
    this.bgGeo.stop()                                                                                         // 88
    this.isStarted = false;                                                                                   // 89
    return true;                                                                                              // 90
  },                                                                                                          // 91
                                                                                                              // 92
  // where is this plugin available?                                                                          // 93
  //   get it whereever we can find it, and assign it to this.bgGeo                                           // 94
  getPlugin: function() {                                                                                     // 95
    if (_.isObject(this.bgGeo)) {                                                                             // 96
      return this.bgGeo;                                                                                      // 97
    }                                                                                                         // 98
    console.log('backgroundGeoLocation ~ ' + typeof backgroundGeoLocation);                                   // 99
    if (typeof backgroundGeoLocation == "object") {                                                           // 100
      this.bgGeo = backgroundGeoLocation || null;                                                             // 101
      if (_.isObject(this.bgGeo)) {                                                                           // 102
        return this.bgGeo;                                                                                    // 103
      }                                                                                                       // 104
    }                                                                                                         // 105
    console.log('window.backgroundGeoLocation ~ ' + typeof window.backgroundGeoLocation);                     // 106
    if (typeof window.backgroundGeoLocation == "object") {                                                    // 107
      this.bgGeo = window.backgroundGeoLocation || null;                                                      // 108
      if (_.isObject(this.bgGeo)) {                                                                           // 109
        return this.bgGeo;                                                                                    // 110
      }                                                                                                       // 111
    }                                                                                                         // 112
    if (typeof window.plugins == "object") {                                                                  // 113
      console.log('window.plugins.backgroundGeoLocation ~ ' + typeof window.plugins.backgroundGeoLocation);   // 114
      if (typeof window.plugins.backgroundGeoLocation == "object") {                                          // 115
        this.bgGeo = window.plugins.backgroundGeoLocation || null;                                            // 116
        if (_.isObject(this.bgGeo)) {                                                                         // 117
          return this.bgGeo;                                                                                  // 118
        }                                                                                                     // 119
      }                                                                                                       // 120
    }                                                                                                         // 121
    if (typeof cordova != "object") {                                                                         // 122
      console.error('No cordova object in global scope');                                                     // 123
      return false;                                                                                           // 124
    }                                                                                                         // 125
    console.log('cordova.backgroundGeoLocation ~ ' + typeof cordova.backgroundGeoLocation);                   // 126
    if (typeof cordova.backgroundGeoLocation == "object") {                                                   // 127
      this.bgGeo = cordova.backgroundGeoLocation || null;                                                     // 128
      if (_.isObject(this.bgGeo)) {                                                                           // 129
        return this.bgGeo;                                                                                    // 130
      }                                                                                                       // 131
    }                                                                                                         // 132
    if (typeof cordova.plugins == "object") {                                                                 // 133
      console.log('cordova.plugins.backgroundGeoLocation ~ ' + typeof cordova.plugins.backgroundGeoLocation); // 134
      if (typeof cordova.plugins.backgroundGeoLocation == "object") {                                         // 135
        this.bgGeo = cordova.plugins.backgroundGeoLocation || null;                                           // 136
        if (_.isObject(this.bgGeo)) {                                                                         // 137
          return this.bgGeo;                                                                                  // 138
        }                                                                                                     // 139
      }                                                                                                       // 140
    }                                                                                                         // 141
for (var key in window) {                                                                                     // 142
  console.log('  window.' + key + ' ~ ' + typeof window[key]);                                                // 143
}                                                                                                             // 144
  },                                                                                                          // 145
                                                                                                              // 146
  /**                                                                                                         // 147
   * Configuration getter and setter                                                                          // 148
   */                                                                                                         // 149
  config: function(options) {                                                                                 // 150
    if (_.isString(options)) {                                                                                // 151
      this.options.url = options;                                                                             // 152
      return this.options;                                                                                    // 153
    }                                                                                                         // 154
    if (!_.isObject(options)) {                                                                               // 155
      return this.options;                                                                                    // 156
    }                                                                                                         // 157
    this.options = _.extend({}, this.options, options);                                                       // 158
    return this.options;                                                                                      // 159
  },                                                                                                          // 160
                                                                                                              // 161
  /**                                                                                                         // 162
   * Setup the common usage for this plugin                                                                   // 163
   */                                                                                                         // 164
  setup: function() {                                                                                         // 165
    if (!_.isNull(this.bgGeo)) {                                                                              // 166
      return true;                                                                                            // 167
    }                                                                                                         // 168
    this.getPlugin();                                                                                         // 169
    if (!_.isObject(this.bgGeo)) {                                                                            // 170
      console.log('GeolocationBG.setup failed = not avail');                                                  // 171
      return false;                                                                                           // 172
    }                                                                                                         // 173
    // update the options with automatic params                                                               // 174
    //   params will be sent in with 'location' in POST data (root level params)                              // 175
    this.options.params.userId = GeolocationBG.userId();                                                      // 176
    this.options.params.uuid = GeolocationBG.uuid();                                                          // 177
    this.options.params.device = GeolocationBG.device();                                                      // 178
                                                                                                              // 179
    // This callback will be executed every time a geolocation is recorded in the background.                 // 180
    //   not used for Android                                                                                 // 181
    var callbackFn = function(location) {                                                                     // 182
      console.log('GeolocationBG: setup: callbackFn: ' + _.values(location).join(','));                       // 183
      console.log('[js] BackgroundGeoLocation callback:  ' + location.latitude + ',' + location.longitude);   // 184
      // Do your HTTP request here to POST location to your server.                                           // 185
      GeolocationBG.send(location);                                                                           // 186
    };                                                                                                        // 187
                                                                                                              // 188
    // This callback will be executed for error                                                               // 189
    //   not used for Android                                                                                 // 190
    var failureFn = function(error) {                                                                         // 191
      console.log('GeolocationBG: setup: failureFn: ' + _.values(error).join(','));                           // 192
      console.log('BackgroundGeoLocation error');                                                             // 193
    }                                                                                                         // 194
                                                                                                              // 195
                                                                                                              // 196
    // BackgroundGeoLocation is highly configurable.                                                          // 197
    // (NOTE: Android service is automatic)                                                                   // 198
    GeolocationBG.bgGeo.configure(callbackFn, failureFn, this.options);                                       // 199
                                                                                                              // 200
    console.log('GeolocationBG: setup: end');                                                                 // 201
    return true;                                                                                              // 202
  },                                                                                                          // 203
                                                                                                              // 204
  /**                                                                                                         // 205
   * Send the location via AJAX to GeolocationBG.url                                                          // 206
   *                                                                                                          // 207
   * @param object location                                                                                   // 208
   */                                                                                                         // 209
  send: function(location) {                                                                                  // 210
    console.log('GeolocationBG: send: ' + JSON.stringify(location));                                          // 211
                                                                                                              // 212
    if (!_.isObject(location)) {                                                                              // 213
      console.error('GeolocationBG: send: error - location is invalid - not an object');                      // 214
      return;                                                                                                 // 215
    }                                                                                                         // 216
    if (_.has(location, 'location')) {                                                                        // 217
      location = location.location;                                                                           // 218
    }                                                                                                         // 219
    if (_.has(location, 'coords')) {                                                                          // 220
      location = location.coords;                                                                             // 221
    }                                                                                                         // 222
    if (!_.has(location, 'longitude')) {                                                                      // 223
      console.error('GeolocationBG: send: error - location is invalid - no coords');                          // 224
      return;                                                                                                 // 225
    }                                                                                                         // 226
                                                                                                              // 227
    var options = _.extend({                                                                                  // 228
      data: {                                                                                                 // 229
        longitude: location.longitude,                                                                        // 230
        latitude: location.latitude,                                                                          // 231
        userId: GeolocationBG.userId(),                                                                       // 232
        uuid: GeolocationBG.uuid(),                                                                           // 233
        device: GeolocationBG.device()                                                                        // 234
      }                                                                                                       // 235
    }, this.options);                                                                                         // 236
                                                                                                              // 237
    HTTP.call('POST', this.options.url, options, function(err, res) {                                         // 238
      if (err) {                                                                                              // 239
        console.error('HTTP.call() callback error');                                                          // 240
        console.error(JSON.stringify(err));                                                                   // 241
        console.log(JSON.stringify(res));                                                                     // 242
        return;                                                                                               // 243
      }                                                                                                       // 244
      console.log('[debugging] HTTP.call() callback');                                                        // 245
      //console.log(JSON.stringify(err));                                                                     // 246
      //console.log(JSON.stringify(res));                                                                     // 247
      GeolocationBG.sendCallbackSuccess(res);                                                                 // 248
    });                                                                                                       // 249
  },                                                                                                          // 250
                                                                                                              // 251
  /**                                                                                                         // 252
   * Send the location via AJAX to GeolocationBG.url                                                          // 253
   *                                                                                                          // 254
   * @param object location                                                                                   // 255
   */                                                                                                         // 256
  sendCallbackSuccess: function(res) {                                                                        // 257
    console.log('GeolocationBG: send: success: ' + res);                                                      // 258
    console.log('[js] BackgroundGeoLocation callback, callback = success' + res);                             // 259
    //                                                                                                        // 260
    // IMPORTANT:  You must execute the #finish method here to inform the native plugin that you're finished, // 261
    //  and the background-task may be completed.  You must do this regardless if your HTTP request is successful or not.
    // IF YOU DON'T, ios will CRASH YOUR APP for spending too much time in the background.                    // 263
    //                                                                                                        // 264
    GeolocationBG.bgGeo.finish();                                                                             // 265
  },                                                                                                          // 266
                                                                                                              // 267
  /**                                                                                                         // 268
   * get the userId                                                                                           // 269
   *                                                                                                          // 270
   * @param object location                                                                                   // 271
   */                                                                                                         // 272
  userId: function() {                                                                                        // 273
    if (!Meteor) {                                                                                            // 274
      return 'noMeteorObj';                                                                                   // 275
    }                                                                                                         // 276
    if (!_.has(Meteor, 'userId')) {                                                                           // 277
      return 'noMeteor.userId';                                                                               // 278
    }                                                                                                         // 279
    if (_.isString(Meteor.userId)) {                                                                          // 280
      return Meteor.userId;                                                                                   // 281
    }                                                                                                         // 282
    try {                                                                                                     // 283
      return Meteor.userId();                                                                                 // 284
    } catch (e) {                                                                                             // 285
      return '?';                                                                                             // 286
    }                                                                                                         // 287
  },                                                                                                          // 288
                                                                                                              // 289
  /**                                                                                                         // 290
   * get the device info basics (tie back to user)                                                            // 291
   *                                                                                                          // 292
   * @param object location                                                                                   // 293
   */                                                                                                         // 294
  device: function() {                                                                                        // 295
    device = device || {};                                                                                    // 296
    if (!_.isObject(device)) {                                                                                // 297
      return 'errDeviceNotObject';                                                                            // 298
    }                                                                                                         // 299
    if (!_.has(device, 'platform')) {                                                                         // 300
      device.platform = '?';                                                                                  // 301
    }                                                                                                         // 302
    if (!_.has(device, 'model')) {                                                                            // 303
      device.model = '?';                                                                                     // 304
    }                                                                                                         // 305
    if (!_.has(device, 'version')) {                                                                          // 306
      device.version = '?';                                                                                   // 307
    }                                                                                                         // 308
    return device.platform + '(' + device.model + ') [' + device.version + ']';                               // 309
  },                                                                                                          // 310
                                                                                                              // 311
  /**                                                                                                         // 312
   * get the device info basics (tie back to user)                                                            // 313
   *                                                                                                          // 314
   * @param object location                                                                                   // 315
   */                                                                                                         // 316
  uuid: function() {                                                                                          // 317
    device = device || {};                                                                                    // 318
    if (!_.isObject(device)) {                                                                                // 319
      return 'errDeviceNotObject';                                                                            // 320
    }                                                                                                         // 321
    if (!_.has(device, 'uuid')) {                                                                             // 322
      device.uuid = '?';                                                                                      // 323
    }                                                                                                         // 324
    return device.uuid;                                                                                       // 325
  },                                                                                                          // 326
                                                                                                              // 327
  /**                                                                                                         // 328
   * Get the navigator.geolocation plugin (foreground)                                                        // 329
   *                                                                                                          // 330
   */                                                                                                         // 331
  getPluginFG: function() {                                                                                   // 332
    if (_.isObject(this.fgGeo)) {                                                                             // 333
      return this.fgGeo;                                                                                      // 334
    }                                                                                                         // 335
    this.fgGeo = window.navigator.geolocation || null;                                                        // 336
    if (_.isObject(this.fgGeo)) {                                                                             // 337
      return this.fgGeo;                                                                                      // 338
    }                                                                                                         // 339
    this.fgGeo = navigator.geolocation || null;                                                               // 340
    if (_.isObject(this.fgGeo)) {                                                                             // 341
      return this.fgGeo;                                                                                      // 342
    }                                                                                                         // 343
    this.fgGeo = geolocation || null;                                                                         // 344
    if (_.isObject(this.fgGeo)) {                                                                             // 345
      return this.fgGeo;                                                                                      // 346
    }                                                                                                         // 347
    console.error('navigator.geolocation does not exist');                                                    // 348
  },                                                                                                          // 349
                                                                                                              // 350
  /**                                                                                                         // 351
   * Get the current/realtime location (not in BG)                                                            // 352
   *                                                                                                          // 353
   * Your app must execute AT LEAST ONE call for the current position via standard Cordova geolocation,       // 354
   * in order to prompt the user for Location permission.                                                     // 355
   */                                                                                                         // 356
  get: function() {                                                                                           // 357
    console.log('GeolocationBG: get: init');                                                                  // 358
    this.getPluginFG();                                                                                       // 359
    if (!_.isObject(this.fgGeo)) {                                                                            // 360
      console.error('GeolocationBG: get: failure... navigator.geolocation not available');                    // 361
      return;                                                                                                 // 362
    }                                                                                                         // 363
    this.fgGeo.getCurrentPosition(function(location) {                                                        // 364
      console.log('GeolocationBG: get: got');                                                                 // 365
      GeolocationBG.send(location);                                                                           // 366
    });                                                                                                       // 367
  }                                                                                                           // 368
                                                                                                              // 369
}                                                                                                             // 370
                                                                                                              // 371
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zeroasterisk:cordova-geolocation-background'] = {
  GeolocationBG: GeolocationBG
};

})();
