(function(){Template.Observations.helpers({
	observations: function() {
		return Observations.find();
	}
});


})();
