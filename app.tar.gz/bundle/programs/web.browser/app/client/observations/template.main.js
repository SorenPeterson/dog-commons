(function(){
Template.__checkName("Observations");
Template["Observations"] = new Template("Template.Observations", (function() {
  var view = this;
  return [ HTML.Raw("<h3>Observations</h3>\n	"), Spacebars.include(view.lookupTemplate("NavBar")), "\n	", Blaze.Each(function() {
    return Spacebars.call(view.lookup("observations"));
  }, function() {
    return [ "\n		", Blaze.View("lookup:content", function() {
      return Spacebars.mustache(view.lookup("content"));
    }), "\n	" ];
  }) ];
}));

})();
