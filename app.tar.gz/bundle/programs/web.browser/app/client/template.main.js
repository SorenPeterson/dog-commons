(function(){
Template.body.addContent((function() {
  var view = this;
  return "";
}));
Meteor.startup(Template.body.renderToDocument);

Template.__checkName("Splash");
Template["Splash"] = new Template("Template.Splash", (function() {
  var view = this;
  return HTML.Raw('<div class="splash-template">\n		<h1>Nature Heals</h1>\n		<div class="button">\n			<a href="/home">Enter</a>\n		</div>\n	</div>');
}));

Template.__checkName("NavBar");
Template["NavBar"] = new Template("Template.NavBar", (function() {
  var view = this;
  return HTML.Raw('<ul>\n		<li><a href="/home">Home</a></li>\n		<li><a href="/map">Map</a></li>\n		<li><a href="/observations">Observations Diary</a></li>\n	</ul>');
}));

Template.__checkName("Home");
Template["Home"] = new Template("Template.Home", (function() {
  var view = this;
  return [ HTML.Raw("<h3>Nature Heals</h3>\n	"), Spacebars.include(view.lookupTemplate("NavBar")) ];
}));

})();
