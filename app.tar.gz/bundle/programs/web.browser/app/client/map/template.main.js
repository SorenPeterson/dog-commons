(function(){
Template.__checkName("Map");
Template["Map"] = new Template("Template.Map", (function() {
  var view = this;
  return [ HTML.Raw("<h3>Map</h3>\n	"), Spacebars.include(view.lookupTemplate("NavBar")), "\n	", HTML.DIV({
    "class": "map-container"
  }, "\n		", Blaze._TemplateWith(function() {
    return {
      name: Spacebars.call("mainMap"),
      options: Spacebars.call(view.lookup("mapOptions"))
    };
  }, function() {
    return Spacebars.include(view.lookupTemplate("googleMap"));
  }), "\n	") ];
}));

})();
